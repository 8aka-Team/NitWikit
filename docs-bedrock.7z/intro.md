---
title: 笨蛋开服教程
sidebar_position: 1
---

# 笨蛋开服教程

👋 欢迎来到笨蛋开服教程基岩板块！

此板块是一篇主要针对 **基岩版** 服务器的开服指南，而非 **Java 版**。

# 开始你的旅程

![:NitWikit](https://count.kjchmc.cn/get/@:NitWikit)

如果您确定您符合条件，请点击一侧的目录开始阅读文档。

# 更多

对于文档中的错误请进入 [Github](https://github.com/postyizhan/NitWikit) 提出 Issue 或提交 Pr。

欢迎加入 [企鹅群 🐧611076407](https://qm.qq.com/q/lEnfzgzxjq)。
