---
title: 开始阶段
slug: /start
sidebar_position: 3
---

# 开始阶段

在这个阶段，我们主要为你介绍服务器基础知识，如何区别客户端和服务端、如何选择服务端、如何搭建并连接等。

import DocCardList from '@theme/DocCardList';

<DocCardList />
