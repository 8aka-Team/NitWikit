---
title: 基础知识
slug: /basic
sidebar_position: 1
---

# 基础知识

考虑到笨蛋教程主要面向新手，我们无法了解你了解什么不了解什么。

本文档暂时就开服最重要的基础概念进行介绍，如果有你自认为非常了解或者不重要的部分，

**跳过他吧**，因为我们在后面再次提到这些概念的时候会重新跳转到对应链接。

import DocCardList from '@theme/DocCardList';

<DocCardList />
